package DevOps404.Inventura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventuraApplicationTests {

	@Test
	void contextLoads() {
	}

}
