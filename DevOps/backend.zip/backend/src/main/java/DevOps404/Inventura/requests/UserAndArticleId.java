package DevOps404.Inventura.requests;

public class UserAndArticleId {

	private Long userId;
	private Long articleId;
	
	public Long getUserId() {
		return userId;
	}
	public Long getArticleId() {
		return articleId;
	}
	
	
}
