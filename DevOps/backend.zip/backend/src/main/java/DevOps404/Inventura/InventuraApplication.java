package DevOps404.Inventura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventuraApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventuraApplication.class, args);
		System.out.println("running");
	}

}
