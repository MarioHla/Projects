﻿using System;
using System.Collections.Generic;
using System.Linq;
using pok1_webAPI.Data;
using pok1_webAPI.Interfaces;
using pok1_webAPI.Models;

namespace pok1_webAPI.Repositories
{
    public class LocationRepository : ILocationRepository
    {
        private readonly DataContext _dbContext;

        public LocationRepository(DataContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<LocationModel> GetAllLocations()
        {
            return _dbContext.Locations.ToList();
        }

        public IEnumerable<LocationModel> GetLocationsByCategory(string category)
        {
            return _dbContext.Locations.Where(l => l.Category == category).ToList();
        }

        public IEnumerable<LocationModel> GetLocationsByName(string query)
        {
            return _dbContext.Locations.AsEnumerable()
                            .Where(l => l.Name.Contains(query, StringComparison.OrdinalIgnoreCase))
                            .ToList();
        }

        public void AddRecord(RecordModel record)
        {
            _dbContext.Records.Add(record);
            _dbContext.SaveChanges();
        }

        public IEnumerable<RecordModel> GetAllRecords()
        {
            return _dbContext.Records.ToList();
        }
    }
}
