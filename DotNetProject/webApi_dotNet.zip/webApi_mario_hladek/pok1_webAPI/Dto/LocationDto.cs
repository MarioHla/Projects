﻿namespace pok1_webAPI.Dto
{
    public class LocationDto
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
